# React Image Compressor


## Functionalities

- Compress Image By Reducing Resolution and Size
- Offline Compression

## Built With

- ReactJS
- React Bootstrap
- Browser Image Compression

## Development

1. Install npm dependencies

```
npm install
```

2. Install browser-image-compression module

```
npm install browser-image-compression
```

3. Run the app locally.

```
npm start
```
